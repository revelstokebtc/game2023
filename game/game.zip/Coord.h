#pragma once

struct Coord {
	int x;
	int y;
};