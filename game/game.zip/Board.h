#pragma once

#include <vector>

class Board
{
public:
	// constructor
	Board();
	Board(int width, int height);

	// class properties
	char ground = '~';

	// class methods
	void draw();

	// @todo: pass in player pointer

private:
	int width;
	int height;
	std::vector<std::vector<char>> screen;
	void initScreen();
};

